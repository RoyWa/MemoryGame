#!/bin/bash

cd  ~/Applications/Google\ Chrome.app/Contents/MacOS/
open -a "Google Chrome" --args --allow-file-access-from-files
